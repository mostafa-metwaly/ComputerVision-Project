
Simple Shapes - v7 HugeDataset
==============================

This dataset was exported via roboflow.ai on March 16, 2021 at 6:45 PM GMT

It includes 777 images.
Cylinder are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Resize to 640x640 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Equal probability of one of the following 90-degree rotations: none, clockwise, counter-clockwise, upside-down
* Randomly crop between 0 and 19 percent of the image


