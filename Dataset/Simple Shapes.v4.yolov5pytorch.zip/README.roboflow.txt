
Simple Shapes - v4 2021-02-25 3:43am
==============================

This dataset was exported via roboflow.ai on February 25, 2021 at 12:43 AM GMT

It includes 57 images.
Cylinder are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 640x640 (Stretch)

No image augmentation techniques were applied.


